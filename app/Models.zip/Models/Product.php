<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'category_id', 'brand_id', 'name', 'slug', 'description',
        'price', 'was_price', 'rating', 'reviews_count',
        'badge', 'image', 'colors', 'gallery', 'stock',
        'is_flash_sale', 'flash_sale_ends_at', 'is_featured', 'storage'
    ];

    protected $casts = [
        'colors' => 'array',
        'gallery' => 'array',
        'is_flash_sale' => 'boolean',
        'flash_sale_ends_at' => 'datetime',
        'storage' => 'array',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

    public function scopeOnFlashSale($query)
    {
        return $query->where('is_flash_sale', true)
            ->where(function ($q) {
                $q->whereNull('flash_sale_ends_at')
                  ->orWhere('flash_sale_ends_at', '>', now());
            });
    }

    public function scopeFeatured($query)
    {
        return $query->where('is_featured', true);
    }

    public function scopeNewArrivals($query)
    {
        return $query->where('badge', 'New');
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    public function ratingBreakdown(): array
    {
        $counts = $this->reviews()
            ->selectRaw('rating, count(*) as count')
            ->groupBy('rating')
            ->pluck('count', 'rating');

        $total = $counts->sum();
        $breakdown = [];

        for ($star = 5; $star >= 1; $star--) {
            $count = $counts[$star] ?? 0;
            $breakdown[$star] = [
                'count' => $count,
                'percent' => $total > 0 ? round($count / $total * 100) : 0,
            ];
        }

        return $breakdown;
    }

    public function recalculateRating(): void
    {
        $this->reviews_count = $this->reviews()->count();
        $this->rating = $this->reviews_count > 0 ? round($this->reviews()->avg('rating'), 1) : 0;
        $this->save();
    }

    public function priceForColor(?string $colorName): int
    {
        if (! $colorName || empty($this->colors)) {
            return $this->price;
        }

        foreach ($this->colors as $color) {
            if (($color['name'] ?? null) === $colorName && ! empty($color['price'])) {
                return (int) $color['price'];
            }
        }

        return $this->price;
    }

        public function priceForStorage(?string $storageName): ?int
    {
        if (! $storageName || empty($this->storage)) {
            return null;
        }

        foreach ($this->storage as $option) {
            if (($option['name'] ?? null) === $storageName && ! empty($option['price'])) {
                return (int) $option['price'];
            }
        }

        return null;
    }

    public function resolvePrice(?string $color, ?string $storage): int
    {
        return $this->priceForStorage($storage) ?? $this->priceForColor($color);
    }
}