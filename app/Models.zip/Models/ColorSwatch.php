<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ColorSwatch extends Model
{
    protected $fillable = ['name', 'hex'];
}